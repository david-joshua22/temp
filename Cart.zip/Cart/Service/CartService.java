package com.example.Cart.Service;

import com.example.Cart.model.Cart;

import java.util.List;

public interface CartService {
    public void addToCart(Cart cartId);
    public boolean removeFromCart(Cart cartId);
    public void updateCartItem(Cart cartId,  String action);
    public List<Cart> getCartDetails();
}
