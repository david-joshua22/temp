package com.example.Cart.Service;

import com.example.Cart.Repository.CartRepository;
import com.example.Cart.model.Cart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Override
    public void addToCart(Cart cart) {
        cartRepository.save(cart);
    }

    @Override
    public boolean removeFromCart(Cart cart) {
        cartRepository.deleteById(cart.getCartId());
        return true;
    }

    @Override
    public void updateCartItem(Cart cart, String action) {
        Optional<Cart> cartItemOptional = cartRepository.findById(cart.getCartId());
        if (cartItemOptional.isPresent()) {
            Cart cartItem = cartItemOptional.get();
            int currentQuantity = cartItem.getQuantity();

            if ("INCREASE".equalsIgnoreCase(action)) {
                cartItem.setQuantity(currentQuantity + 1);
                cartRepository.save(cartItem);
            } else if ("DECREASE".equalsIgnoreCase(action)) {
                if (currentQuantity > 1) {
                    cartItem.setQuantity(currentQuantity - 1);
                    cartRepository.save(cartItem);
                } else {
                    cartRepository.delete(cartItem);
                }
            } else {
                throw new IllegalArgumentException("Unsupported cart action: " + action);
            }
        } else {
            throw new RuntimeException("No cart item found with the given ID");
        }
    }

    @Override
    public List<Cart> getCartDetails() {
        return cartRepository.findAll(); // Assuming you want to return all cart items
    }
}
