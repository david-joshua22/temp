package com.example.Cart.Repository;

import com.example.Cart.model.Cart;
import com.example.Cart.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;

public interface CartRepository extends JpaRepository<Cart,Integer> {
    List<Cart> findByUserId(User userId);
    Optional<Cart> findByUserIdAndProductId(User userId, Integer productId);
}
