package com.example.Cart.Controller;

import com.example.Cart.Service.CartServiceImpl;
import com.example.Cart.model.Cart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/")
public class CartController {

    @Autowired
    private CartServiceImpl cartService;

    @GetMapping("/cart")
    public String getAllCarts(Model model){
        // Dummy cart item
        List<Map<String, Object>> cartItems = new ArrayList<>();
        Map<String, Object> item = new HashMap<>();
        item.put("id", 1);
        item.put("name", "Sample Product");
        item.put("price", 999);
        item.put("quantity", 1);
        item.put("imageUrl", "/images/watch (1).jpg");
        item.put("deliveryEstimate", "Sep 2 - Sep 5");
        cartItems.add(item);
        model.addAttribute("cartItems", cartItems);
        model.addAttribute("subtotal", 999);
        model.addAttribute("shipping", 50);
        return "cart";
    }

    @PostMapping("/addToCart")
    public ResponseEntity<String> addToCart(@RequestBody Cart cart) {
        cartService.addToCart(cart);
        return ResponseEntity.ok("Item added to cart");
    }
    @DeleteMapping("/cart/{cartId}")
        public ResponseEntity<String> removeFromCart(@PathVariable Cart cartId)
    {
        cartService.removeFromCart(cartId);
        return ResponseEntity.ok("Item Removed from Cart");
    }
    @PutMapping("/updateCart")
    public ResponseEntity<String> updateCartItem(@RequestBody Cart cart,@RequestParam String action)
    {
        cartService.updateCartItem(cart, action);
        return ResponseEntity.ok("Cart Item updated successfully");
    }

}
