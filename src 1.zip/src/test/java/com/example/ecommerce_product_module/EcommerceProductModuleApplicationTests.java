package com.example.ecommerce_product_module;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceProductModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
