package com.example.ecommerce_product_module;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceProductModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceProductModuleApplication.class, args);
	}
}
