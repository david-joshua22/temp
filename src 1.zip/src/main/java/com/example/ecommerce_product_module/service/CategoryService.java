package com.example.ecommerce_product_module.service;

import com.example.ecommerce_product_module.model.Category;
import java.util.List;

public interface CategoryService {
    List<Category> getAllCategories();
}
